package com.example.antiphi;

public class sites {
public String[] site = {"ngork","serveo","http"};

public int checkdot(String url)
{
    int count =0;
    for(int i=0;i<url.length();i++)
    {
        if(url.charAt(i)=='.')
        {
            count++;
        }
    }
    return count;
}
    public int checkSlash(String url)
    {
        int count2 =0;
        for(int i=0;i<url.length();i++)
        {
            if(url.charAt(i)=='.')
            {
                count2++;
            }
        }
        return count2;
    }

public int check1(String url)
{
     String[] urlArray = url.split(".");
     int count1 = checkdot(url);
     int count = 0;
     for(int i=0;i<=count1;i++)
     {
         if(urlArray[i].equals("ngork") || urlArray[i].equals("serveo"))
         {
             count=2;
         }
         else if(urlArray[i].equals("http"))
         {
             count=1;
         }
     }
     return count;
}
    public int check2(String url)
    {
        int count1 = checkdot(url);
        int count2 = checkSlash(url);
        int count = 0;
        for(int i=0;i<=count1;i++)
        {
            if(count1>4&&count2>8)
            {
                count = 3;
            }
            else if(count1<4&&count2>8)
            {
                count =2 ;
            }
            else if(count1<4&&count2<8)
            {
                count = 1;
            }
        }
        return count;
    }

}

