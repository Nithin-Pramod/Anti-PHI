package com.example.antiphi;
import android.app.Activity;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.net.URL;

public class Main2Activity extends AppCompatActivity {
//    URL url;
    EditText mUrl;
    TextView mResult,mReport;
    Button mButton;
    sites sites =new sites();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        mResult = (TextView)findViewById(R.id.textView4);
        mButton = (Button)findViewById(R.id.button);
        mUrl = (EditText)findViewById(R.id.editText);
        mReport = (TextView) findViewById(R.id.textView5);
        final int[] a = new int[1];
        mButton.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View view) {
                closeKeyBoard();
                try{
                    Uri url = Uri.parse(mUrl.getText().toString());
                    String host = url.getHost();
                    String serveo = "serveo.net";
                    String ngrok = "ngrok.com";
                    int port = url.getPort();
                    String path = url.getPath();
                    String Query = url.getQuery();
                    String PathSegment = url.getLastPathSegment();
                    String Scheme = url.getScheme();
                    boolean opaque = url.isOpaque();
                    int HC = url.hashCode();
                    mResult.setText("Fetching Data..............\n" + "Analyzing information........\n\n\n" +
                            "HOST : " + host + "\nPORT : " + port + "\nSCHEME : " + Scheme + "\nPATH : " + path + "\nQUERY : " + Query + "\nPATH SEGMENT : " + PathSegment + "\nHASH CODE : " + HC
                            + "\nOPAQUE : " + opaque);
                    if (Scheme.equals("http"))
                    {
                        if ((host.equals(serveo) || host.equals(ngrok))&& Scheme.equals("http")) {
                            mReport.setText("Can contain Threats because it hosted on PHISHING servers!!!!1");
                        }
                        else {
                            mReport.setText("NOT SECURE , MAY CONTAIN THREATS.");
                            }
                        }
                    else {
                        if(host.equals(serveo) || host.equals(ngrok))
                        {
                            mReport.setText("Can contain Threats because it hosted on PHISHING servers!!!!1");
                        }
                        else
                        {
                            mReport.setText("SECURE");
                        }
                        }
                }
                catch (NullPointerException e)
                {
                    mResult.setText("Please enter a valid URL !!!");
                    mReport.setText("   ");
                }
            }


        });

    }
    private void closeKeyBoard(){
        View view = this.getCurrentFocus();
        if (view != null){
            InputMethodManager imm = (InputMethodManager)
                    getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

}
